package com.example.var10

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
    }

    fun riga(view: View) {
            val intent = Intent(this, MainActivity4::class.java)
            intent.putExtra("city", "Рига")
            startActivity(intent)

    }

    fun kishinev(view: View) {val intent = Intent(this, MainActivity4::class.java)
            intent.putExtra("city", "Кишинев")
            startActivity(intent)}

    fun ToMenu(view: View) {
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)

    }
}